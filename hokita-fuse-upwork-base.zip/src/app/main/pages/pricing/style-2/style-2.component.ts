import { Component } from '@angular/core';

@Component({
    selector   : 'pricing-style-2',
    templateUrl: './style-2.component.html',
    styleUrls  : ['./style-2.component.scss']
})
export class PricingStyle2Component
{
    /**
     * Constructor
     */
    constructor()
    {

    }

}
