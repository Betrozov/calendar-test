import { Component } from '@angular/core';

@Component({
    selector   : 'pricing-style-3',
    templateUrl: './style-3.component.html',
    styleUrls  : ['./style-3.component.scss']
})
export class PricingStyle3Component
{
    /**
     * Constructor
     */
    constructor()
    {

    }

}
