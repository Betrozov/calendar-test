import { Component } from '@angular/core';

@Component({
    selector   : 'search',
    templateUrl: './search.component.html',
    styleUrls  : ['./search.component.scss']
})
export class SearchComponent
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
