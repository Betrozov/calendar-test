export const locale = {
    lang: 'en',
    data: {
        'SAMPLE': {
            'HELLO': 'Hello, World!'
        }
    }
};
