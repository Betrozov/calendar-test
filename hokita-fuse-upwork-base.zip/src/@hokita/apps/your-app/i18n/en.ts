export const locale = {
    lang: 'en',
    data: {
        'YOUR-APP': {
            'HELLO': 'Hello world!'
        }
    }
};
