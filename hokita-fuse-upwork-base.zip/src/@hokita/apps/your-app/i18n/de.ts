export const locale = {
    lang: 'de',
    data: {
        'YOUR-APP': {
            'HELLO': 'Hallo Welt'
        }
    }
};
