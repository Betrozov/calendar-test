export const locale = {
    lang: 'de',
    data: {
        'SAMPLE': {
            'HELLO': 'Hallo Welt!'
        }
    }
};
