
export interface Privilege {
    privilege: string;
}
